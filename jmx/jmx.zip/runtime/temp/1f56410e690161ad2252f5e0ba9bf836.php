<?php /*a:1:{s:58:"E:\phpstudy\WWW\jmx\application\jmx\view\address\form.html";i:1569481129;}*/ ?>
<form class="layui-form layui-card"><input type="hidden" name="id" value="<?php echo isset($data['id']) ? htmlentities($data['id']) : ''; ?>"><div class="layui-card-body"><div class="layui-form-item"><label class="layui-form-label label-required-next">用户名称</label><div class="layui-input-block"><select name="uid" lay-verify="coach_id" lay-filter="coach_id"><option value=""></option><?php if(is_array($user) || $user instanceof \think\Collection || $user instanceof \think\Paginator): $i = 0; $__LIST__ = $user;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo htmlentities($vo['id']); ?>" <?php if($vo['id']== $data['uid']): ?>selected<?php endif; ?>><?php echo htmlentities($vo['nickname']); ?></option><?php endforeach; endif; else: echo "" ;endif; ?></select></div></div><div class="layui-form-item"><div class="layui-inline"><label class="layui-form-label label-required-next">类型</label><div class="layui-input-inline"><select name="type" lay-verify="week"><option value="">请选择类型</option><option value="1" <?php if($data['type']=='家'): ?>selected<?php endif; ?>>家</option><option value="2" <?php if($data['type']=='公司'): ?>selected<?php endif; ?>>公司</option><option value="3" <?php if($data['type']=='常用地址'): ?>selected<?php endif; ?>>常用地址</option></select></div></div></div><div class="layui-form-item"><label class="layui-form-label label-required-next">联系电话</label><div class="layui-input-block"><input type="text" name="tel" lay-verify="required|number" autocomplete="off"
                       placeholder="请输入联系电话"
                       class="layui-input" value="<?php echo isset($data['tel']) ? htmlentities($data['tel']) : ''; ?>"></div></div><div class="layui-form-item"><label class="layui-form-label label-required-next">地址</label><div class="layui-input-block"><textarea placeholder="请输入地址" class="layui-textarea"
                          name="address" lay-verify="effect"><?php echo htmlentities((isset($data['address']) && ($data['address'] !== '')?$data['address']:"")); ?></textarea></div></div></div><div class="hr-line-dashed"></div><div class="layui-form-item text-center"><button class="layui-btn" type='button' lay-submit="" lay-filter="submit">保存数据</button><button class="layui-btn layui-btn-danger" type='button' data-confirm="确定要取消编辑吗？" data-close>取消编辑</button></div><script>window.form.render();</script></form><script>
    layui.config({
        base: "/static/plugs/layui/lay/mymodules/"
    }).use(['form', 'layer', 'eleTree', 'upload'], function () {
        var form = layui.form
            , layer = layui.layer, upload = layui.upload;
        var eleTree = layui.eleTree;
        var uploadInst = upload.render({
            elem: '#cateBtn',
            url: '<?php echo url("upload/upload"); ?>',
            done: function (res) {
                if (res.code > 0) {
                    $('#cover_image').val(res.url);
                    $('#cateImage').attr('src', res.url);
                } else {
                    //如果上传失败
                    return layer.msg('上传失败');
                }
            },
            error: function () {
                //演示失败状态，并实现重传
                var demoText = $('#demoText');
                demoText.html('<span style="color: #FF5722;">上传失败</span><a class="layui-btn layui-btn-mini demo-reload">重试</a>');
                demoText.find('.demo-reload').on('click', function () {
                    uploadInst.upload();
                });
            }
        });


        form.on('submit(submit)', function (data) {
            var loading = layer.load(1, {shade: [0.1, '#fff']});
            $.post("<?php echo url('edit'); ?>", data.field, function (res) {
                layer.close(loading);
                if (res.status == 'success') {
                    layer.msg(res.msg, {time: 1800, icon: 1}, function () {
                        //关闭当前frame
                        location.reload()
                    });
                } else {
                    layer.msg(res.msg, {time: 1800, icon: 2});
                }
            });
        });


    });
</script>
