<?php /*a:1:{s:59:"E:\phpstudy\WWW\jmx\application\jmx\view\vouchers\form.html";i:1569398554;}*/ ?>
<form class="layui-form layui-card"><input type="hidden" name="id" value="<?php echo isset($data['id']) ? htmlentities($data['id']) : ''; ?>"><div class="layui-card-body"><div class="layui-form-item"><label class="layui-form-label label-required-next">优惠券名称</label><div class="layui-input-block"><input type="text" name="title" lay-verify="required" autocomplete="off"
                       placeholder="请输入优惠券名称"
                       class="layui-input" value="<?php echo htmlentities($data['title']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label label-required-next">优惠券金额</label><div class="layui-input-block"><input type="text" name="price" lay-verify="required|number" autocomplete="off"
                       placeholder="请输入优惠券金额"
                       class="layui-input" value="<?php echo htmlentities($data['price']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label label-required-next">达到金额使用</label><div class="layui-input-block"><input type="text" name="full" lay-verify="required|number" autocomplete="off"
                       class="layui-input" value="<?php echo isset($data['full']) ? htmlentities($data['full']) : 0; ?>"></div></div><div class="layui-form-item"><label class="layui-form-label">使用要求</label><div class="layui-input-block"><input type="text" name="describe" autocomplete="off"
                       placeholder="满20元可用"
                       class="layui-input" value="<?php echo htmlentities($data['describe']); ?>"></div></div></div><div class="hr-line-dashed"></div><div class="layui-form-item text-center"><button class="layui-btn" type='button' lay-submit="" lay-filter="submit">保存数据</button><button class="layui-btn layui-btn-danger" type='button' data-confirm="确定要取消编辑吗？" data-close>取消编辑</button></div><script>window.form.render();</script></form><script>
    layui.use(['form', 'layer'], function () {
        var form = layui.form
            , layer = layui.layer;
        form.on('submit(submit)', function (data) {
            var loading = layer.load(1, {shade: [0.1, '#fff']});
            $.post("<?php echo url('edit'); ?>", data.field, function (res) {
                layer.close(loading);
                if (res.status == 'success') {
                    layer.msg(res.msg, {time: 1800, icon: 1}, function () {
                        //关闭当前frame
                        location.reload()
                    });
                } else {
                    layer.msg(res.msg, {time: 1800, icon: 2});
                }
            });
        });
    });
</script>
