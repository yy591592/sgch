<?php /*a:1:{s:56:"E:\phpstudy\WWW\jmx\application\jmx\view\order\form.html";i:1570497640;}*/ ?>
<form class="layui-form layui-card"><input type="hidden" name="id" value="<?php echo isset($data['id']) ? htmlentities($data['id']) : ''; ?>"><div class="layui-card-body"><div class="layui-form-item"><label class="layui-form-label">用户名称</label><div class="layui-input-block"><input type="text"  lay-verify="name" readonly autocomplete="off"
                       class="layui-input" value="<?php echo htmlentities($data['uid']); ?>"></div></div><div class="layui-form-item"><div class="layui-inline"><label class="layui-form-label label-required-next">类型</label><div class="layui-input-inline"><select name="type" lay-verify="week"><option value="">请选择类型</option><option value="1" <?php if($data['type']=='帮代购'): ?>selected<?php endif; ?>>帮代购</option><option value="2" <?php if($data['type']=='帮取送'): ?>selected<?php endif; ?>>帮取送</option><option value="3" <?php if($data['type']=='帮排队'): ?>selected<?php endif; ?>>帮排队</option><option value="4" <?php if($data['type']=='万能跑腿'): ?>selected<?php endif; ?>>万能跑腿</option></select></div></div></div><div class="layui-form-item"><label class="layui-form-label">手机号</label><div class="layui-input-block"><input type="text" name="tel" autocomplete="off"
                       class="layui-input" value="<?php echo htmlentities($data['tel']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label">订单号</label><div class="layui-input-block"><input type="text" name="order_number" autocomplete="off"
                       class="layui-input" value="<?php echo htmlentities($data['order_number']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label">订单状态</label><div class="layui-input-block"><input type="text" name="process" autocomplete="off"
                       class="layui-input"  readonly value="<?php echo htmlentities($data['process']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label">取货地址</label><div class="layui-input-block"><input type="text" name="de_address" autocomplete="off"
                       class="layui-input" value="<?php echo htmlentities($data['de_address']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label">收货地址</label><div class="layui-input-block"><input type="text" name="re_address" autocomplete="off"
                       class="layui-input" value="<?php echo htmlentities($data['re_address']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label">购买/排队时间</label><div class="layui-input-block"><input type="text" name="time" autocomplete="off"
                       class="layui-input" value="<?php echo htmlentities($data['time']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label">订单金额</label><div class="layui-input-block"><input type="text" name="price" autocomplete="off"
                       class="layui-input" value="<?php echo htmlentities($data['price']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label">跑腿费</label><div class="layui-input-block"><input type="text" name="run_price" autocomplete="off"
                       class="layui-input" value="<?php echo htmlentities($data['run_price']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label">时长</label><div class="layui-input-block"><input type="text" name="timelong" autocomplete="off"
                       class="layui-input" value="<?php echo htmlentities($data['timelong']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label">下单时间</label><div class="layui-input-block"><input type="text" name="addtime" autocomplete="off"
                       class="layui-input" value="<?php echo htmlentities($data['addtime']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label">商品重量</label><div class="layui-input-block"><input type="text" name="weight" autocomplete="off"
                       class="layui-input" value="<?php echo htmlentities($data['weight']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label label-required-next">内容详情</label><div class="layui-input-block"><textarea placeholder="请输入内容详情" class="layui-textarea"
                          name="content" lay-verify="crowd"><?php echo htmlentities((isset($data['content']) && ($data['content'] !== '')?$data['content']:"")); ?></textarea></div></div><?php if($data['type']=='帮代购'): ?><div class="layui-form-item"><label class="layui-form-label">指定跑腿员</label><div class="layui-input-block"><input type="text" name="run_id" autocomplete="off"
                       class="layui-input" value="<?php echo htmlentities($data['run_id']); ?>"></div></div><div class="layui-form-item"><label class="layui-form-label">指定商家</label><div class="layui-input-block"><input type="text" name="store_id" autocomplete="off"
                       class="layui-input" value="<?php echo htmlentities($data['store_id']); ?>"></div></div><?php endif; if($data['type']=='万能跑腿'): ?><div class="layui-form-item"><label class="layui-form-label">是否通过审核</label><div class="layui-input-block"><input type="checkbox" name="status" <?php if(1==$data['status']): ?>checked<?php endif; ?> lay-skin="switch"
                       lay-text="ON|OFF"></div></div><?php endif; ?></div><div class="hr-line-dashed"></div><div class="layui-form-item text-center"><button class="layui-btn" type='button' lay-submit="" lay-filter="submit">保存数据</button><button class="layui-btn layui-btn-danger" type='button' data-confirm="确定要取消编辑吗？" data-close>取消编辑</button></div><script>window.form.render();</script></form><script>
    layui.config({
        base: "/static/plugs/layui/lay/mymodules/"
    }).use(['form', 'layer', 'eleTree', 'upload'], function () {
        var form = layui.form
            , layer = layui.layer, upload = layui.upload;
        var eleTree = layui.eleTree;
        var uploadInst = upload.render({
            elem: '#cateBtn',
            url: '<?php echo url("upload/upload"); ?>',
            done: function (res) {
                if (res.code > 0) {
                    $('#cover_image').val(res.url);
                    $('#cateImage').attr('src', res.url);
                } else {
                    //如果上传失败
                    return layer.msg('上传失败');
                }
            },
            error: function () {
                //演示失败状态，并实现重传
                var demoText = $('#demoText');
                demoText.html('<span style="color: #FF5722;">上传失败</span><a class="layui-btn layui-btn-mini demo-reload">重试</a>');
                demoText.find('.demo-reload').on('click', function () {
                    uploadInst.upload();
                });
            }
        });


        form.on('submit(submit)', function (data) {
            var loading = layer.load(1, {shade: [0.1, '#fff']});
            $.post("<?php echo url('edit'); ?>", data.field, function (res) {
                layer.close(loading);
                if (res.status == 'success') {
                    layer.msg(res.msg, {time: 1800, icon: 1}, function () {
                        //关闭当前frame
                        location.reload()
                    });
                } else {
                    layer.msg(res.msg, {time: 1800, icon: 2});
                }
            });
        });


    });
</script>
