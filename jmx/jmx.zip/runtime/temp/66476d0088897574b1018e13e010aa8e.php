<?php /*a:2:{s:65:"E:\phpstudy\WWW\jmx\application\jmx\view\user\authentication.html";i:1570514113;s:52:"E:\phpstudy\WWW\jmx\application\admin\view\main.html";i:1564817296;}*/ ?>
<div class="layui-card layui-bg-gray"><?php if(!(empty($title) || (($title instanceof \think\Collection || $title instanceof \think\Paginator ) && $title->isEmpty()))): ?><div class="layui-card-header layui-anim layui-anim-fadein notselect"><span class="layui-icon layui-icon-next font-s10 color-desc margin-right-5"></span><?php echo htmlentities((isset($title) && ($title !== '')?$title:'')); ?><div class="pull-right"></div></div><?php endif; ?><div class="layui-card-body layui-anim layui-anim-upbit"><div class="think-box-shadow"><fieldset class="demoTable"><legend>条件搜索</legend><form class="layui-form layui-form-pane form-search"><div class="layui-form-item layui-inline"><label class="layui-form-label">用户名称</label><div class="layui-input-inline"><input name="nickname" id="nickname" value="<?php echo htmlentities((app('request')->get('nickname') ?: '')); ?>" placeholder="请输入用户名称"
                           class="layui-input"></div></div><div class="layui-form-item layui-inline"><button class="layui-btn" id="search" type="button"><i class="layui-icon">&#xe615;</i>搜索</button><button class="layui-btn" id="all" data-type="reload" onclick="location.reload()">显示全部</button></div></form></fieldset><table class="layui-table" id="list" lay-filter="list"></table></div></div><script>form.render()</script><script type="text/html" id="topBtn"><button type="button" class="layui-btn layui-btn-danger layui-btn-sm" id="delAll">批量删除</button></script><script type="text/html" id="action"><a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del">删除</a></script><script type="text/html" id="statusTpl"><input type="checkbox" name="valid" lay-skin="switch" data-id="{{d.id}}" lay-filter="switchTest" lay-text="通过|待审核"
           {{ d.is_run== "1" ? "checked" : "0" }}></script><script>    layui.use(['table', 'form'], function () {
        var table = layui.table, form = layui.form, $ = layui.jquery;
        var tableIn = table.render({
            id: 'user',
            elem: '#list',
            url: '<?php echo url("auth_list"); ?>',
            method: 'post',
            toolbar: '#topBtn',
            page: true,
            cols: [[
                {checkbox: true, fixed: true},
                {field: 'id', align: 'center', title: '用户ID', width: 80, fixed: true},
                {field: 'nickname', align: 'center', title: '用户名称', width: 120},
                {field: 'tel', align: 'center', title: '联系电话', width: 120},
                {field: 'city', align: 'center', title: '意向工作城市', width: 120},
                {field: 'address', align: 'center', title: '意向工作地址', width: 120},
                {field: 'run_type', align: 'center', title: '意向工作类型', width: 120},
                // {field: 'is_run', align: 'center', title: '审核状态', width: 120},
                {field: 'is_run', title: '状态', align: 'center', templet: '#statusTpl', width: 120},

                {width: 120, title: '操作', align: 'center', toolbar: '#action', fixed: "right"},
            ]],
            limit: 10 //每页默认显示的数量
        });


        form.on('switch(switchTest)', function (data) {
            var id = $(this).attr('data-id');
            var valid = this.checked ? '1' : '0';

            //获取当前行的id ,valid 点击发送ajax到后台
            $.ajax({
                type: 'POST',
                url: '<?php echo url("switchs"); ?>',
                data: {id: id, valid: valid},
                dataType: 'json',
                success: function (res) {
                    if (res.status == 'success') {
                        parent.layer.msg('修改成功', {icon: 6, time: 2000});
                    }
                },
                error: function (res) {
                    if (res.code == 'fail') {
                        parent.layer.msg('修改失败', {icon: 5, time: 2000});
                        console.log(res);
                    }
                }
            })
        })


        //搜索
        $('#search').on('click', function () {
            var name = $('#nickname').val();
            tableIn.reload({
                where: {
                    name: name,
                }
            });
        });
        table.on('tool(list)', function (obj) {
            var data = obj.data;
            if (obj.event === 'del') {
                layer.confirm('您确定要删除吗？', function (index) {
                    var loading = layer.load(1, {shade: [0.1, '#fff']});
                    var ids = [];
                    ids.push(data.id)
                    $.post("<?php echo url('delete'); ?>", {id: ids}, function (res) {
                        layer.close(loading);
                        if (res.status == 'success') {
                            layer.msg(res.msg, {time: 1000, icon: 1});
                            tableIn.reload();
                        } else {
                            layer.msg('操作失败！', {time: 1000, icon: 2});
                        }
                    });
                    layer.close(index);
                });
            } else if (obj.event === 'images') {
                $.post("<?php echo url('getImages'); ?>", {id: data.id}, function (result) {
                    layer.photos({
                        photos: result //格式见API文档手册页
                        , anim: 5 //0-6的选择，指定弹出图片动画类型，默认随机
                    });
                })
            }
        });
        $('body').on('click', '#delAll', function () {
            layer.confirm('确认要删除选中信息吗？', {icon: 3}, function (index) {
                layer.close(index);
                var checkStatus = table.checkStatus('coach'); //topnews即为参数id设定的值
                var ids = [];
                $(checkStatus.data).each(function (i, o) {
                    ids.push(o.id);
                });
                var loading = layer.load(1, {shade: [0.1, '#fff']});
                $.post("<?php echo url('delete'); ?>", {id: ids}, function (data) {
                    layer.close(loading);
                    if (data.status == 'success') {
                        layer.msg(data.msg, {time: 1000, icon: 1});
                        tableIn.reload();
                    } else {
                        layer.msg(data.errmsg, {time: 1000, icon: 2});
                    }
                });
            });
        })
    });
</script></div>