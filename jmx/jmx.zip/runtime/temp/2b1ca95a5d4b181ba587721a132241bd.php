<?php /*a:2:{s:59:"E:\phpstudy\WWW\jmx\application\jmx\view\address\index.html";i:1569480568;s:52:"E:\phpstudy\WWW\jmx\application\admin\view\main.html";i:1564817296;}*/ ?>
<div class="layui-card layui-bg-gray"><?php if(!(empty($title) || (($title instanceof \think\Collection || $title instanceof \think\Paginator ) && $title->isEmpty()))): ?><div class="layui-card-header layui-anim layui-anim-fadein notselect"><span class="layui-icon layui-icon-next font-s10 color-desc margin-right-5"></span><?php echo htmlentities((isset($title) && ($title !== '')?$title:'')); ?><div class="pull-right"></div></div><?php endif; ?><div class="layui-card-body layui-anim layui-anim-upbit"><div class="think-box-shadow"><table class="layui-table" id="list" lay-filter="list"></table></div></div><script>form.render()</script><script type="text/html" id="topBtn"><button data-modal='<?php echo url("add"); ?>' data-title="添加" class='layui-btn layui-btn-sm'>添加</button><button type="button" class="layui-btn layui-btn-danger layui-btn-sm" id="delAll">批量删除</button></script><script type="text/html" id="action"><button data-modal='<?php echo url("add"); ?>?id={{d.id}}' data-title="编辑" class='layui-btn layui-btn-xs'>编辑</button><a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del">删除</a></script><script type="text/html" id="order"><input name="{{d.id}}" data-id="{{d.id}}" class="list_order layui-input" value="{{d.sort}}" size="10"
           style="height: 25px;line-height: 25px;"/></script><script type="text/html" id="time"><input readonly class="list_order layui-input" value="{{d.createtime}}" size="10"
           style="height: 25px;line-height: 25px;"/></script><script>    layui.use(['table', 'form'], function () {
        var table = layui.table, form = layui.form, $ = layui.jquery;
        var tableIn = table.render({
            id: 'notice',
            elem: '#list',
            url: '<?php echo url("getList"); ?>',
            method: 'post',
            toolbar: '#topBtn',
            page: true,
            cols: [[
                {checkbox: true, fixed: true},
                {field: 'id', align: 'center', title: 'ID', width: 80, fixed: true},
                {field: 'uid', align: 'center', title: '用户名称', width: 80, fixed: true},
                {field: 'type', align: 'center', title: '类型', width: 120},
                {field: 'tel', align: 'center', title: '联系电话', width: 120},
                {field: 'address', align: 'center', title: '地址', width: 120},
                {width: 120, title: '操作', align: 'center', toolbar: '#action', fixed: "right"},
            ]],
            limit: 10 //每页默认显示的数量
        });
        //搜索
        $('#search').on('click', function () {
            var name = $('#name').val();
            tableIn.reload({
                where: {
                    name: name,
                }
            });
        });
        table.on('tool(list)', function (obj) {
            var data = obj.data;
            if (obj.event === 'del') {
                layer.confirm('您确定要删除吗？', function (index) {
                    var loading = layer.load(1, {shade: [0.1, '#fff']});
                    var ids = [];
                    ids.push(data.id)
                    $.post("<?php echo url('delete'); ?>", {id: ids}, function (res) {
                        layer.close(loading);
                        if (res.status == 'success') {
                            layer.msg(res.msg, {time: 1000, icon: 1});
                            tableIn.reload();
                        } else {
                            layer.msg('操作失败！', {time: 1000, icon: 2});
                        }
                    });
                    layer.close(index);
                });
            } else if (obj.event === 'images') {
                $.post("<?php echo url('getImages'); ?>", {id: data.id}, function (result) {
                    layer.photos({
                        photos: result //格式见API文档手册页
                        , anim: 5 //0-6的选择，指定弹出图片动画类型，默认随机
                    });
                })
            }
        });
        //排序
        $('body').on('blur', '.list_order', function () {
            loading = layer.load(1, {shade: [0.1, '#fff']});
            var id = $(this).attr('data-id');
            var sort = $(this).val();
            $.post("<?php echo url('editSort'); ?>", {id: id, sort: sort}, function (result) {
                layer.close(loading);
                if (result.status == "success") {
                    layer.msg(result.msg, {time: 1000, icon: 1});
                    treeGrid.render;
                } else {
                    layer.msg(result.msg, {time: 1000, icon: 2});
                    treeGrid.render;
                    return false;
                }
            })
        })

        $('body').on('click', '#delAll', function () {
            layer.confirm('确认要删除选中信息吗？', {icon: 3}, function (index) {
                layer.close(index);
                var checkStatus = table.checkStatus('notice'); //topnews即为参数id设定的值
                var ids = [];
                $(checkStatus.data).each(function (i, o) {
                    ids.push(o.id);
                });
                var loading = layer.load(1, {shade: [0.1, '#fff']});
                $.post("<?php echo url('delete'); ?>", {id: ids}, function (data) {
                    layer.close(loading);
                    if (data.status == 'success') {
                        layer.msg(data.msg, {time: 1000, icon: 1});
                        tableIn.reload();
                    } else {
                        layer.msg(data.errmsg, {time: 1000, icon: 2});
                    }
                });
            });
        })
    });
</script></div>