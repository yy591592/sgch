<?php /*a:1:{s:60:"E:\phpstudy\WWW\jmx\application\jmx\view\order_buy\form.html";i:1569393881;}*/ ?>
<form class="layui-form layui-card"><input type="hidden" name="id" value="<?php echo isset($data['id']) ? htmlentities($data['id']) : ''; ?>"><div class="layui-card-body"><div class="layui-form-item"><label class="layui-form-label">标题</label><div class="layui-input-block"><input type="text" name="title" lay-verify="name" autocomplete="off"
                       placeholder="请输入标题"
                       class="layui-input" value="<?php echo htmlentities($data['title']); ?>"></div></div><div class="layui-form-item"><div class="layui-inline"><label class="layui-form-label label-required-next">类型</label><div class="layui-input-inline"><select name="type" lay-verify="week"><option value="">请选择类型</option><option value="1" <?php if($data['type']=='通知'): ?>selected<?php endif; ?>>通知</option><option value="2" <?php if($data['type']=='公告'): ?>selected<?php endif; ?>>公告</option></select></div></div></div><div class="layui-form-item"><label class="layui-form-label label-required-next">内容详情</label><div class="layui-input-block"><textarea placeholder="请输入内容详情" class="layui-textarea"
                          name="content" lay-verify="crowd"><?php echo htmlentities((isset($data['content']) && ($data['content'] !== '')?$data['content']:"")); ?></textarea></div></div><div class="layui-inline"><div class="layui-form-item"><label class="layui-form-label">排序</label><div class="layui-input-inline"><input type="number" name="sort" placeholder="请输入排序序号" autocomplete="off" class="layui-input"
                           value="<?php echo isset($data['sort']) ? htmlentities($data['sort']) : 100; ?>"></div></div></div></div><div class="hr-line-dashed"></div><div class="layui-form-item text-center"><button class="layui-btn" type='button' lay-submit="" lay-filter="submit">保存数据</button><button class="layui-btn layui-btn-danger" type='button' data-confirm="确定要取消编辑吗？" data-close>取消编辑</button></div><script>window.form.render();</script></form><script>
    layui.config({
        base: "/static/plugs/layui/lay/mymodules/"
    }).use(['form', 'layer', 'eleTree', 'upload'], function () {
        var form = layui.form
            , layer = layui.layer, upload = layui.upload;
        var eleTree = layui.eleTree;
        var uploadInst = upload.render({
            elem: '#cateBtn',
            url: '<?php echo url("upload/upload"); ?>',
            done: function (res) {
                if (res.code > 0) {
                    $('#cover_image').val(res.url);
                    $('#cateImage').attr('src', res.url);
                } else {
                    //如果上传失败
                    return layer.msg('上传失败');
                }
            },
            error: function () {
                //演示失败状态，并实现重传
                var demoText = $('#demoText');
                demoText.html('<span style="color: #FF5722;">上传失败</span><a class="layui-btn layui-btn-mini demo-reload">重试</a>');
                demoText.find('.demo-reload').on('click', function () {
                    uploadInst.upload();
                });
            }
        });


        form.on('submit(submit)', function (data) {
            var loading = layer.load(1, {shade: [0.1, '#fff']});
            $.post("<?php echo url('edit'); ?>", data.field, function (res) {
                layer.close(loading);
                if (res.status == 'success') {
                    layer.msg(res.msg, {time: 1800, icon: 1}, function () {
                        //关闭当前frame
                        location.reload()
                    });
                } else {
                    layer.msg(res.msg, {time: 1800, icon: 2});
                }
            });
        });


    });
</script>
